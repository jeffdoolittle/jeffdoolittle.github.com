﻿using System;

namespace NewRelic.Numbers.Util
{
    public class Class1
    {
    }
}
