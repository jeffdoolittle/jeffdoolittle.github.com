using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NewRelic.Numbers.Host.Console
{
  public class SocketListener
  {
    private string data = null;

    public void StartListening()
    {
      IPAddress ipAddress = IPAddress.Loopback;
      IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 8181);

      System.Console.WriteLine($"Local address and port : {localEndPoint.ToString()}");

      // Data buffer for incoming data.  
      byte[] bytes = new Byte[1024];

      // Establish the local endpoint for the socket.  
      // Dns.GetHostName returns the name of the
      // host running the application.  

      // Create a TCP/IP socket.  
      Socket listener = new Socket(ipAddress.AddressFamily,
          SocketType.Stream, ProtocolType.Tcp);

      // Bind the socket to the local endpoint and
      // listen for incoming connections.  
      try
      {
        listener.Bind(localEndPoint);
        listener.Listen(5);

        // Start listening for connections.  
        while (true)
        {
          System.Console.WriteLine("Waiting for a connection...");
          // Program is suspended while waiting for an incoming connection.  
          Socket handler = listener.Accept();
          data = null;

          // An incoming connection needs to be processed.  
          try
          {
            while (true)
            {
              int bytesRec = handler.Receive(bytes);
              data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
              if (data.IndexOf("<EOF>") > -1)
              {
                break;
              }
            }
          }
          catch (SocketException)
          {
            break;
          }

          // Show the data on the console.  
          System.Console.WriteLine("Text received : {0}", data);

          // Echo the data back to the client.  
          byte[] msg = Encoding.ASCII.GetBytes(data);

          handler.Send(msg);
          handler.Shutdown(SocketShutdown.Both);
          handler.Close();
        }

      }
      catch (Exception e)
      {
        System.Console.WriteLine(e.ToString());
      }

      System.Console.WriteLine("\nPress ENTER to continue...");
      System.Console.Read();
    }
  }

  public class StateObject
  {
    public Socket workSocket = null;
    public const int BufferSize = 1024;
    public byte[] buffer = new byte[BufferSize];
    public StringBuilder sb = new StringBuilder();
  }
}
