namespace NewRelic.Numbers.System
{
  public class PipelineContracts
  {
    
  }
}
