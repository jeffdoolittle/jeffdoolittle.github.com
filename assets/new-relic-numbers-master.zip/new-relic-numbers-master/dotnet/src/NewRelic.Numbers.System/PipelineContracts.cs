﻿using System;
using System.Threading;

public delegate void LoggingDelegate(string level, string format, params object[] parameters);

namespace NewRelic.Numbers.System
{
  public interface Cancelable
  {
    CancellationToken CancellationToken { get; }
  }

  public struct Unit
  {
    static Unit()
    {
      Default = new Unit();
    }

    public static Unit Default { get; }

    public override string ToString()
    {
      return "<Unit>";
    }
  }

  public interface PipelineStepBuilder<TContext, TInput>
  {
    PipelineStepBuilder<TContext, Unit> HandleError(string name, Func<TContext, Exception, bool> handle,
      Func<string, Exception, bool> filter = null);

    PipelineStepBuilder<TContext, TInput> Before(string name, Func<TContext, TInput, bool> before,
      Func<TContext, TInput, string, bool> filter = null);

    PipelineStepBuilder<TContext, TInput> After(string name, Action<TContext, TInput, object> after,
      Func<TContext, TInput, object, string, bool> filter = null);

    PipelineStepBuilder<TContext, TOutput> Step<TOutput>(string name, Func<TContext, TInput, TOutput> func = null,
      Func<TContext, TOutput, bool> continueIf = null);

    PipelineStepBuilder<TContext, TOutput> Step<TOutput>(string name, Func<TContext, TInput, bool> func,
      Func<TContext, TInput, TOutput> left,
      Func<TContext, TInput, TOutput> right
      );

    PipelineStepBuilder<TContext, Unit> Step(string name, Action<TContext, TInput> func);

    PipelineStepBuilder<TContext, Unit> Step(string name, Func<TContext, TInput, bool> func,
      Action<TContext, TInput> left,
      Action<TContext, TInput> right
      );
  }

  public interface PipelineRunner<TContext, TPayload>
  {
    PipelineRunner<TContext, TPayload> LogWith(LoggingDelegate logger, string level);
    void Run(TContext context, TPayload payload);
  }
}
