﻿using System.IO;

namespace NewRelic.Numbers.System
{
  public interface IngressContext : Cancelable
  {
    SystemConfiguration Configuration { get; }
    Decoder Decoder { get; }
    Validator Validator { get; }
    Deduplicator Deduplicator { get; }
    EventsAccessor Events { get; }
    StatisticsAccessor Stats { get; }
    void Terminate();
  }

  public interface IngressProcessor
  {
    void Process(byte[] bytes);
  }

  public interface Decoder
  {
    string Decode(byte[] bytes);
  }

  public interface Validator
  {
    ValidationResult Validate(string value, string newLine);
  }

  public interface ValidationResult
  {
    string CleanValue { get; }
    bool IsValid { get; }
  }

  public interface Deduplicator
  {
    DeduplicatorResult Check(string value);
  }

  public interface DeduplicatorResult
  {
    string Value { get; }
    bool IsUnique { get; }
  }

  public interface EventsAccessor : Clearable
  {
    void Append(string value);
  }

  public interface StatisticsAccessor : Clearable
  {
    void Increment(string measurement);

    void Write(StatisticsContext context);
  }

  public interface StatisticsContext
  {
    Stream Stream { get; }
    bool ResetIntervalMeasurements { get; }
    bool ResetTotalMeasurements { get; }
  }

  public interface DistinctValuesAccessor : Clearable
  {
    bool IsDistinct(string value);
  }

  public interface Clearable
  {
    void Clear();
  }

  public interface Logger
  {
    void WriteLine(string level, string message);
  }
}
