using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace NewRelic.Numbers.System
{
  public class PipelineModel<TContext>
  {
    private readonly List<Tuple<string, Func<TContext, object, object>>> _steps
        = new List<Tuple<string, Func<TContext, object, object>>>();

    private readonly List<Tuple<string, Func<TContext, object, string, bool>>> _beforeMiddlewares =
      new List<Tuple<string, Func<TContext, object, string, bool>>>();

    private readonly List<Tuple<string, Action<TContext, object, object, string>>> _afterMiddlewares =
      new List<Tuple<string, Action<TContext, object, object, string>>>();

    private readonly List<Tuple<string, Func<TContext, Exception, bool>>> _errorHandlers =
      new List<Tuple<string, Func<TContext, Exception, bool>>>();

    public void Add<TInput, TOutput>(string name, Func<TContext, TInput, TOutput> step)
    {
      Func<TContext, object, object> func = (ctx, input) => step(ctx, (TInput)input);
      _steps.Add(Tuple.Create(name, func));
    }

    public void AddBefore<TInput>(string name, Func<TContext, TInput, bool> before, Func<TContext, TInput, string, bool> filter = null)
    {
      Func<TContext, object, string, bool> func = (ctx, input, name) =>
      {
        var shouldExecute = filter?.Invoke(ctx, (TInput)input, name) ?? false;
        if (shouldExecute)
        {
          return before(ctx, (TInput)input);
        }
        return true;
      };

      _beforeMiddlewares.Add(Tuple.Create(name, func));
    }

    public void AddAfter<TInput, TOutput>(string name, Action<TContext, TInput, TOutput> after, Func<TContext, TInput, TOutput, string, bool> filter = null)
    {
      Action<TContext, object, object, string> action = (ctx, input, output, name) =>
      {
        var shouldExecute = filter?.Invoke(ctx, (TInput)input, (TOutput)output, name) ?? false;
        if (shouldExecute)
        {
          after(ctx, (TInput)input, (TOutput)output);
        }
      };

      _afterMiddlewares.Insert(0, Tuple.Create(name, action));
    }

    public void AddErrorHandler(string name, Func<TContext, Exception, bool> handle, Func<string, Exception, bool> filter = null)
    {
      Func<TContext, Exception, bool> func = (ctx, ex) =>
      {
        filter = filter == null ? (name, ex) => true : filter;

        if (filter(name, ex))
        {
          return handle(ctx, ex);
        }

        return false;
      };

      _errorHandlers.Add(Tuple.Create(name, func));
    }

    public void Run<TInput>(TContext context, TInput input, Action<string, string, object[]> logger)
    {
      var runContext = new PipelineRunContext(context, this, logger);

      var sw = new Stopwatch();
      sw.Start();

      runContext.Log("INF", $"Starting run: {DateTimeOffset.UtcNow:o}");

      object nextInput = input;
      foreach (var step in _steps)
      {
        runContext.Log("DBG", "Starting step: {0}", step.Item1);

        var continueExecution = Before(context, input, runContext);
        if (!continueExecution)
        {
          break;
        }

        try
        {
          runContext.Log("DBG", "Executing step: {0}", step.Item1);

          var currentInput = nextInput;
          nextInput = step.Item2(context, currentInput);

          runContext.Log("INF", "Executed step: {0} ({1},{2})", step.Item1, currentInput, nextInput);
        }
        catch (Exception ex)
        {
          foreach (var handler in _errorHandlers)
          {
            var handled = handler.Item2(context, ex);
            if (!handled)
            {
              runContext.Log("ERR", $"An unhandled exception occurred:{Environment.NewLine}{ex.StackTrace}");
              throw;
            }
            else
            {
              runContext.Log("WRN", $"A handled exception occurred: {ex.GetType().Name}:{Environment.NewLine}{ex.Message}");
            }
          }
        }

        After(runContext);
      }

      sw.Stop();

      runContext.Log("INF", $"Finished run: {DateTimeOffset.UtcNow:o}");
      runContext.Log("INF", $"Elapsed: {sw.Elapsed.TotalMilliseconds * 1000} µs");
    }

    private bool Before<TInput>(TContext context, TInput input, PipelineRunContext runContext)
    {
      var continueExecution = true;
      foreach (var before in _beforeMiddlewares)
      {
        runContext.Log("DBG", "Invoking before: {0}", before.Item1);

        continueExecution = before.Item2(context, input, before.Item1);
        if (!continueExecution)
        {
          break;
        }
      }

      return continueExecution;
    }

    private void After(PipelineRunContext runContext)
    {
      foreach (var after in _afterMiddlewares)
      {
        runContext.Log("DBG", "Invoking after: {0}", after.Item1);
      }
    }

    private class PipelineRunContext
    {
      private readonly TContext context;
      private readonly Action<string, string, object[]> log;

      public PipelineRunContext(TContext context, PipelineModel<TContext> model, Action<string, string, object[]> logger)
      {
        this.context = context;
        this.log = logger != null ? logger : (lvl, format, parameters) => {};
      }

      public void Log(string lvl, string format, params object[] parameters)
      {
        log(lvl, format, parameters);
      }
    }
  }
}
