using System;

namespace NewRelic.Numbers.System
{
  public class IngressProcessorImpl : IngressProcessor
  {
    private readonly IngressContext context;
    private readonly LoggingDelegate logger;

    public IngressProcessorImpl(IngressContext context, LoggingDelegate logger)
    {
      this.context = context;
      this.logger = logger;
    }

    public void Process(byte[] bytes)
    {
      PipelineBuilder
        .For<IngressContext, byte[]>(_ => _
            .Step("decode", (ctx, input) => ctx.Decoder.Decode(input),
              (ctx, result) => !string.IsNullOrEmpty(result))
            .Step("validate", (ctx, input) => ctx.Validator.Validate(input, context.Configuration.NewLine),
                (ctx, result) => result.IsValid)
            .Step("getMessage", (ctx, result) => result.CleanValue)
            .Step("check-termination", (ctx, input) =>
            {
              var terminate = context.Configuration.TerminateMessage.Equals(input);
              return new Tuple<bool, string>(terminate, input);
            }, (ctx, input) => input.Item1)
            .Step("notTerminating", (ctx, input) => input.Item2)
            .Step("deduplicate", (ctx, input) => ctx.Deduplicator.Check(input))
            .Step("handle-message", (ctx, input) => !input.IsUnique,
              (ctx, input) => ctx.Stats.Increment("duplicate"),
              (ctx, input) =>
              {
                ctx.Events.Append(input.Value);
                ctx.Stats.Increment("unique");
              }
            )
        )
        .LogWith(logger, level: "DBG")
        .Run(context, bytes);
    }
  }
}
