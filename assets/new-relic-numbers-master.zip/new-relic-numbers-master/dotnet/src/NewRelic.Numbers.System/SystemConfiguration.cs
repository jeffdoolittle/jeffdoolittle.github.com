using System;
using System.Text;

namespace NewRelic.Numbers.System
{
  public interface SystemConfiguration
  {
    // The tcp port to open and listen on for receiving client requests.
    int Port => 4000;

    // The maximum length of the pending connections queue.
    int Backlog => 5;

    // The native new line sequence for the host os.
    string NewLine => Environment.NewLine;

    // The client message which results in host termination.
    string TerminateMessage => "terminate";

    Encoding Encoding => Encoding.UTF8;
  }
}
