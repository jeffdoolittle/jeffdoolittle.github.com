using System;
using System.Threading;
using Microsoft.Extensions.Logging;

namespace NewRelic.Numbers.System
{
  public class PipelineBuilder
  {
    public static PipelineRunner<TContext, TInput> For<TContext, TInput>(Action<PipelineStepBuilder<TContext, TInput>> build)
      where TContext : Cancelable
    {
      return new PipelineRunnerImpl<TContext, TInput>(build);
    }
    private class PipelineStepBuilderImpl<TContext, TInput> : PipelineStepBuilder<TContext, TInput>
    {
      private readonly PipelineModel<TContext> model;

      public PipelineStepBuilderImpl(PipelineModel<TContext> model)
      {
        this.model = model;
      }

      public PipelineStepBuilder<TContext, TInput> Before(string name, Func<TContext, TInput, bool> before, Func<TContext, TInput, string, bool> filter = null)
      {
        model.AddBefore(name, before, filter);
        return new PipelineStepBuilderImpl<TContext, TInput>(model);
      }

      public PipelineStepBuilder<TContext, TInput> After(string name, Action<TContext, TInput, object> after, Func<TContext, TInput, object, string, bool> filter = null)
      {
        model.AddAfter(name, after, filter);
        return new PipelineStepBuilderImpl<TContext, TInput>(model);
      }

      public PipelineStepBuilder<TContext, Unit> HandleError(string name, Func<TContext, Exception, bool> handle, Func<string, Exception, bool> filter = null)
      {
        model.AddErrorHandler(name, handle, filter);
        return new PipelineStepBuilderImpl<TContext, Unit>(model);
      }

      public PipelineStepBuilder<TContext, TOutput> Step<TOutput>(string name, Func<TContext, TInput, TOutput> func, Func<TContext, TOutput, bool> continueIf = null)
      {
        model.Add<TInput, TOutput>(name, (ctx, input) => (TOutput)func(ctx, (TInput)input));
        return new PipelineStepBuilderImpl<TContext, TOutput>(model);
      }

      public PipelineStepBuilder<TContext, Unit> Step(string name, Action<TContext, TInput> action)
      {
        Func<TContext, TInput, Unit> func = ((ctx, input) =>
        {
          action(ctx, input);
          return Unit.Default;
        });

        model.Add<TInput, Unit>(name, (ctx, input) => func(ctx, (TInput)input));
        return new PipelineStepBuilderImpl<TContext, Unit>(model);
      }

      public PipelineStepBuilder<TContext, TOutput> Step<TOutput>(string name, Func<TContext, TInput, bool> predicate, Func<TContext, TInput, TOutput> left, Func<TContext, TInput, TOutput> right)
      {
        Func<TContext, TInput, TOutput> func = (ctx, input) =>
        {
          if (predicate(ctx, input))
          {
            return left(ctx, input);
          }
          else
          {
            return right(ctx, input);
          }
        };

        model.Add<TInput, TOutput>(name, (ctx, input) => (TOutput)func(ctx, (TInput)input));
        return new PipelineStepBuilderImpl<TContext, TOutput>(model);
      }
      public PipelineStepBuilder<TContext, Unit> Step(string name, Func<TContext, TInput, bool> predicate, Action<TContext, TInput> left, Action<TContext, TInput> right)
      {
        Func<TContext, TInput, Unit> func = (ctx, input) =>
        {
          if (predicate(ctx, input))
          {
            left(ctx, input);
          }
          else
          {
            right(ctx, input);
          }
          return Unit.Default;
        };

        model.Add<TInput, Unit>(name, (ctx, input) => func(ctx, (TInput)input));
        return new PipelineStepBuilderImpl<TContext, Unit>(model);
      }
    }

    private class PipelineRunnerImpl<TContext, TInput> : PipelineRunner<TContext, TInput>
    {
      private readonly PipelineModel<TContext> model;
      private readonly Action<PipelineStepBuilder<TContext, TInput>> build;

      private Action<string, string, object[]> logger;

      public PipelineRunnerImpl(Action<PipelineStepBuilder<TContext, TInput>> build)
      {
        this.model = new PipelineModel<TContext>();
        this.build = build;
      }

      public PipelineRunner<TContext, TInput> LogWith(LoggingDelegate logger, string level)
      {
        this.logger = Wrap(level, logger);
        return this;
      }

      private Action<string, string, object[]> Wrap(string minimumLevel, LoggingDelegate logger)
      {
        var minimumLogLevel = Convert(minimumLevel);
        return ((lvl, format, parameters) =>
        {
          var currentLevel = Convert(lvl);
          if (currentLevel >= minimumLogLevel)
          {
            logger(lvl, format, parameters);
          }
        });
      }

      private LogLevel Convert(string level)
      {
        switch (level)
        {
          case "TRX":
            return LogLevel.Trace;
          case "DBG":
            return LogLevel.Debug;
          case "INF":
            return LogLevel.Information;
          case "WRN":
            return LogLevel.Warning;
          case "ERR":
            return LogLevel.Error;
          default:
            return LogLevel.None;
        }
      }

      public void Run(TContext context, TInput payload)
      {
        var builder = new PipelineStepBuilderImpl<TContext, TInput>(model);
        build(builder);
        model.Run(context, payload, logger);
      }
    }
  }
}
