using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using FakeItEasy;
using Xunit;
using Xunit.Abstractions;
using System.Text;

namespace NewRelic.Numbers.System.Tests
{
  public class PipelineBuilderTests
  {
    private readonly ITestOutputHelper outputHelper;

    public PipelineBuilderTests(ITestOutputHelper outputHelper)
    {
      this.outputHelper = outputHelper;
    }

    [Fact]
    public void test()
    {
      var context = new TestContext(x => outputHelper.WriteLine(x));

      PipelineBuilder
        .For<TestContext, string>(_ => _
          .Step("init", (ctx, input) => input)
          .Step("reverse", (ctx, input) =>
          {
            var arr = input.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
          })
          .Step("console-write", (ctx, input) =>
          {
            Console.WriteLine(input);
            return input;
          })
          .Step("throw-null-reference-ex", (ctx, input) => throw new NullReferenceException("test"))
          .HandleError("error-handler", (ctx, ex) =>
          {
            return true;
          }, (name, ex) => ex is NullReferenceException)
        )
        .LogWith(context.Log, level: "DBG")
        .Run(context, "foobar");
    }

    public class TestContext : Cancelable
    {
      private List<string> _messages = new List<string>();
      private readonly Action<string> logger;

      public TestContext(Action<string> logger)
      {
        this.logger = logger;
      }

      public void Log(string level, string format, params object[] values)
      {
        var message = $"[{level}] {string.Format(format, values)}";
        _messages.Add(message);
        logger(message);
      }

      public IReadOnlyList<string> Messages => _messages;

      public CancellationToken CancellationToken => default;
    }
  }
}
