﻿using System;
using FakeItEasy;
using Xunit;
using Xunit.Abstractions;

namespace NewRelic.Numbers.System.Tests
{
  public class IngressProcessorImplTests
  {
    private readonly IngressContext context;
    private readonly IngressProcessorImpl processor;

    public IngressProcessorImplTests(ITestOutputHelper output)
    {
      this.context = A.Fake<IngressContext>();
      this.processor = new IngressProcessorImpl(this.context,
        (l, f, p) => output.WriteLine($"[{l}] {string.Format(f, p)}"));
    }

    [Fact]
    public void run_processor()
    {
      byte[] bytes = null;

      this.processor.Process(bytes);
    }
  }
}
