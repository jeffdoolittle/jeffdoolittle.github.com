package com.jdfx.numbers.host;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SocketHostTest {
  @Test
  void appHasAGreeting() {
    assertTrue(true);
  }
}