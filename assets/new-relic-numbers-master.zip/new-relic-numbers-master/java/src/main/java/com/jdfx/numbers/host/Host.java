package com.jdfx.numbers.host;

import java.util.function.Supplier;

public interface Host {
  void run(Supplier<Boolean> terminatingSupplier);
}