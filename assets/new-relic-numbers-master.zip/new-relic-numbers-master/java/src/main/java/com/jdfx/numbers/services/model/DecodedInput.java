package com.jdfx.numbers.services.model;

public class DecodedInput {
  private String input;

  public DecodedInput(String input) {
    super();
    this.input = input;
  }

  @Override
  public String toString() {
    return input;
  }
}