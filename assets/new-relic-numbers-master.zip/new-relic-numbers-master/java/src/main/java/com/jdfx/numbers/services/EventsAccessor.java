package com.jdfx.numbers.services;

public interface EventsAccessor {
  void append(String value);
}