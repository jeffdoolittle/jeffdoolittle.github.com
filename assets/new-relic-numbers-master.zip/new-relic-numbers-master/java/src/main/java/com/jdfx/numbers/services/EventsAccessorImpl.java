package com.jdfx.numbers.services;

import java.util.function.BiConsumer;

public class EventsAccessorImpl implements EventsAccessor {

  private BiConsumer<Services, String> writer;
  private Services services;

  public EventsAccessorImpl(Services services, BiConsumer<Services, String> writer) {
    super();
    this.services = services;
    this.writer = writer;
  }

  @Override
  public void append(String value) {
    synchronized (this) {
      writer.accept(services, value);
    }
  }
}