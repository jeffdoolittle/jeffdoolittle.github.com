package com.jdfx.numbers.util;

public enum LogLevel {
  TRX(0),
  DBG(1),
  INF(2),
  WRN(3),
  ERR(4),
  CRI(5);

  private int level;

  private LogLevel(int level)
  {
    this.level = level;
  }

  public int level() {
    return this.level;
  }
}