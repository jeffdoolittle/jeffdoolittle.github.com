package com.jdfx.numbers.services;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

import com.jdfx.numbers.services.model.StatisticsContext;

public class InMemoryStatisticsAccessor implements StatisticsAccessor {
  private static Map<String, Integer> _globalStats = new HashMap<String, Integer>();
  private static Map<String, Integer> _intervalStats = new HashMap<String, Integer>();
  private Services services;

  public InMemoryStatisticsAccessor(final Services services) {
    super();
    this.services = services;

    _globalStats.put(StatisticsAccessor.UNIQUE, 0);
    _globalStats.put(StatisticsAccessor.DUPLICATE, 0);
    _intervalStats.put(StatisticsAccessor.UNIQUE, 0);
    _intervalStats.put(StatisticsAccessor.DUPLICATE, 0);
  }

  @Override
  public void increment(final String key) {
    synchronized (this) {
      _globalStats.put(key, _globalStats.get(key) + 1);
      _intervalStats.put(key, _intervalStats.get(key) + 1);
    }
  }

  @Override
  public void write(final StatisticsContext context) {
    synchronized (this) {
      final var format = "Received %s unique numbers, %s duplicates. Unique total: %s";

      var intervalUnique = _intervalStats.get(StatisticsAccessor.UNIQUE);
      var intervalDuplicates = _intervalStats.get(StatisticsAccessor.DUPLICATE);
      var totalUnique = _globalStats.get(StatisticsAccessor.UNIQUE);

      var stats = String.format(format, intervalUnique, intervalDuplicates, totalUnique);

      var streamWriter = new OutputStreamWriter(context.stream());     
      var writer = new BufferedWriter(streamWriter);
      try {
        writer.write(stats);
        writer.newLine();
        writer.flush();
      } catch (final IOException e) {
        services.log(e);
      }
      
      if (context.resetTotalMeasurements()) {
        for (var key : _globalStats.keySet()) {
          _globalStats.put(key, 0);
        }
      }
      if (context.resetIntervalMeasurements()) {
        for (var key : _intervalStats.keySet()) {
          _intervalStats.put(key, 0);
        }
      }
    }
  }
}