package com.jdfx.numbers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.jdfx.numbers.host.ConsoleHost;
import com.jdfx.numbers.host.Host;
import com.jdfx.numbers.host.SocketHost;
import com.jdfx.numbers.services.AppConfiguration;
import com.jdfx.numbers.services.Services;
import com.jdfx.numbers.services.ServicesImpl;

public class App {
    private static volatile boolean terminating = false;

    public static void main(String[] args) throws IOException {

        var useSocket = args == null || args.length == 0 || args[0] == "socket";

        final var config = new AppConfiguration() {
        };

        Path path = Paths.get(config.eventsResourceName());
        Files.deleteIfExists(path);
        var file = new FileWriter(config.eventsResourceName(), true);
        var writer = new BufferedWriter(file);

        Services services = new ServicesImpl(config, (svcs, event) -> {
            try {
                writer.write(event);
                writer.newLine();
                writer.flush();
            } catch (IOException e) {
                svcs.log(e);
            }
        }, status -> App.terminate(status));

        Host host = null;

        if (useSocket) {
            host = new SocketHost(services);            
        } else {
            host = new ConsoleHost(services, args);
        }

        host.run(() -> terminating);
    }

    private static void terminate(int status) {
        terminating = true;
        System.exit(status);
    }
}