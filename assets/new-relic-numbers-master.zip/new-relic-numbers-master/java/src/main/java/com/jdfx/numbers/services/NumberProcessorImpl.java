package com.jdfx.numbers.services;

import java.io.InputStream;

import com.jdfx.numbers.util.NumbersException;

public class NumberProcessorImpl implements NumberProcessor {
  private Services services;

  public NumberProcessorImpl(Services services) {
    super();
    this.services = services;
  }

  @Override
  public void process(InputStream stream) {
    try {
      var config = services.configuration();

      var decoded = services.decoder().Decode(stream, config.charset(), config.newline());

      var validationResult = services.validator().validate(decoded);
      if (!validationResult.isValid()) {
        throw new NumbersException(validationResult.errorMessage());
      }

      if (validationResult.validatedValue().equals(config.terminateMessage())) {
        services.terminate(0);
        return;
      }

      var deduplicationResult = services.deduplicator().check(validationResult.validatedValue());
      var isDuplicate = !deduplicationResult.IsUnique();

      if (isDuplicate)
      {
        services.stats().increment(StatisticsAccessor.DUPLICATE);
      }
      else
      {
        services.events().append(deduplicationResult.value());
        services.stats().increment(StatisticsAccessor.UNIQUE);
      }

    } catch (Exception e) {
      services.log(e);
    }
  }
}