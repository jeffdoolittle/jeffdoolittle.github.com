package com.jdfx.numbers.host;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.function.Supplier;

import com.jdfx.numbers.services.Services;
import com.jdfx.numbers.services.model.StatisticsContext;

public class SocketHost implements Host {

  private Services services;

  public SocketHost(Services services) {
    super();
    this.services = services;
  }

  @Override
  public void run(Supplier<Boolean> terminatingSupplier) {

    var config = services.configuration();

    try (var serverSocket = new ServerSocket(config.port(), config.backlog())) {

      services.log("INF", "Server socket opened on port %s with max %s concurrent connections", config.port(), config.backlog());
      
      configureStatistics(terminatingSupplier);

      do {

        Socket socket = null;

        try {

          socket = serverSocket.accept();
          services.log("INF", "Client connected: %s", socket.getInetAddress());

          services.log("DBG", "Spawning new Thread for client: %s", socket.getInetAddress());
          Thread t = new SocketClientHandler(services, socket);
          t.start();

        } catch (IOException ex) {
          services.log(ex);
          continue;
        }

      } while (!terminatingSupplier.get());

    } catch (IOException ex) {
      services.log(ex);
    }
    services.terminate(0);
  }

  private void configureStatistics(Supplier<Boolean> terminatingSupplier) {
    Thread statsThread = new Thread() {
        public void run() {
            do
                try {
                    Thread.sleep(services.configuration().statisticsIntervalMilliseconds());
                    services.stats().write(new StatisticsContext(System.out, true, false));
                } catch (InterruptedException e) {
                    services.log(e);
                }
            while (!terminatingSupplier.get());
        }
    };
    statsThread.start();
}

}