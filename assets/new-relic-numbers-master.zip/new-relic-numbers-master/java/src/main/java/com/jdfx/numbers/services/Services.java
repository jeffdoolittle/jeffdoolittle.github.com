package com.jdfx.numbers.services;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public interface Services {
  AppConfiguration configuration();
  Decoder decoder();
  Validator validator();
  Deduplicator deduplicator();
  EventsAccessor events();
  StatisticsAccessor stats();
  void log(String level, String format, Object... parameters);

  default void log(Exception e) {
      var output = new ByteArrayOutputStream();
      var printStream = new PrintStream(output);
      e.printStackTrace(printStream);
      var stackTrace = output.toString();

      this.log("ERR", stackTrace);
  }

  void terminate(int status);

  NumberProcessor processor();
}