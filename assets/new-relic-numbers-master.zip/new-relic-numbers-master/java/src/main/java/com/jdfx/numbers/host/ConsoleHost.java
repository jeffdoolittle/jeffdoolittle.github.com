package com.jdfx.numbers.host;

import java.io.InputStream;
import java.time.Instant;
import java.util.Date;
import java.util.function.Supplier;
import com.jdfx.numbers.services.Services;
import com.jdfx.numbers.services.model.StatisticsContext;
import com.jdfx.numbers.util.ByteBufferInputStream;

public class ConsoleHost implements Host {

  private String[] args;
  private Services services;

  public ConsoleHost(Services services, String[] args) {
    super();
    this.services = services;
    this.args = args;
  }

  @Override
  public void run(Supplier<Boolean> terminatingSupplier) {

    var config = services.configuration();
    var start = Instant.now();

    for (int i = 1; i < args.length; i++) {

      var input = args[i] + config.newline();
      var bb = config.charset().encode(input);

      try (InputStream stream = new ByteBufferInputStream(bb)) {
        var processor = services.processor();
        processor.process(stream);

        if (Instant.now().toEpochMilli() - start.toEpochMilli() > services.configuration().statisticsIntervalMilliseconds()){
          services.stats().write(new StatisticsContext(System.out, true, false));
        }

      } catch (Exception ex) {
        services.log(ex);
      }
    }    
  }
}
