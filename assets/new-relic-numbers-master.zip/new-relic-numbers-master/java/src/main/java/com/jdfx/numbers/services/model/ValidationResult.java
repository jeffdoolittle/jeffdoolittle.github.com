package com.jdfx.numbers.services.model;

public interface ValidationResult {
  String validatedValue();
  boolean isValid();
  String errorMessage();
}