package com.jdfx.numbers.services.model;

public interface DeduplicatorResult {
  String value();
  boolean IsUnique();
}
