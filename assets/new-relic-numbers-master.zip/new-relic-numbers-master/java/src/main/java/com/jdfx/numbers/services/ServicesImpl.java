package com.jdfx.numbers.services;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.jdfx.numbers.util.Lazy;

public class ServicesImpl implements Services {

  private final AppConfiguration configuration;
  private final Supplier<Decoder> decoderSupplier;
  private final Supplier<Validator> validatorSupplier;
  private final Supplier<Deduplicator> deduplicatorSupplier;
  private final Supplier<EventsAccessor> eventsSupplier;
  private final Supplier<StatisticsAccessor> statsSupplier;
  private final Consumer<Integer> terminateConsumer;
  private final Supplier<NumberProcessor> processorSupplier;

  public ServicesImpl(final AppConfiguration configuration, final BiConsumer<Services, String> eventsWriter,
      final Consumer<Integer> terminate) {
    super();
    this.configuration = configuration;
    this.terminateConsumer = terminate;

    this.decoderSupplier = () -> new Decoder() {
    };

    this.validatorSupplier = () -> new ValidatorImpl(this.configuration);

    var lazyDeduplicator = new Lazy<Deduplicator>();
    this.deduplicatorSupplier = () -> lazyDeduplicator.getOrCompute(() -> new InMemoryDeduplicator() {
    });

    var lazyEventsAccessor = new Lazy<EventsAccessor>();
    this.eventsSupplier = () -> lazyEventsAccessor.getOrCompute(() -> new EventsAccessorImpl(this, eventsWriter) {
    });

    var lazyStatsAccessor = new Lazy<StatisticsAccessor>();
    this.statsSupplier = () -> lazyStatsAccessor.getOrCompute(() -> new InMemoryStatisticsAccessor(this) {
    });

    this.processorSupplier = () -> new NumberProcessorImpl(this);
  }

  @Override
  public AppConfiguration configuration() {
    return configuration;
  }

  @Override
  public Decoder decoder() {
    return this.decoderSupplier.get();
  }

  @Override
  public Validator validator() {
    return this.validatorSupplier.get();
  }

  @Override
  public Deduplicator deduplicator() {
    return this.deduplicatorSupplier.get();
  }

  @Override
  public EventsAccessor events() {
    return this.eventsSupplier.get();
  }

  @Override
  public StatisticsAccessor stats() {
    return this.statsSupplier.get();
  }

  @Override
  public void log(final String level, final String format, final Object... parameters) {
    final var template = String.format("[%s] - %s", level, format);
    final var message = String.format(template, parameters);
    System.out.println(message);
  }

  @Override
  public void terminate(final int status) {
    log("INF", "Shutting down...");
    terminateConsumer.accept(status);
  }

  public NumberProcessor processor() {
    return this.processorSupplier.get();
  }
}