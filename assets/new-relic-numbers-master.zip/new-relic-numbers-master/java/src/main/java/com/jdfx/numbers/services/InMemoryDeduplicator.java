package com.jdfx.numbers.services;

import java.util.HashSet;

import com.jdfx.numbers.services.model.DeduplicatorResult;

public class InMemoryDeduplicator implements Deduplicator {
  private static HashSet<Integer> _cache;

  static
  {
    _cache = new HashSet<Integer>(1024 * 1024);
  }

  @Override
  public DeduplicatorResult check(String value) {
    synchronized(this) {
      var key = Integer.parseInt(value);
      var isDuplicate = _cache.contains(key);

      if (!isDuplicate) {
        _cache.add(key);
      }

      return new DeduplicatorResult() {
      
        @Override
        public String value() {
          return value;
        }
      
        @Override
        public boolean IsUnique() {
          return !isDuplicate;
        }
      };
    }
  }
}