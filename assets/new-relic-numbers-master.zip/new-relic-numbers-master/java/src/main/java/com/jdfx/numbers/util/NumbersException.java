package com.jdfx.numbers.util;

public class NumbersException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public NumbersException(String message) {
    super(message);
  }

  public NumbersException(String message, Exception cause) {
    super(message, cause);
  }
}