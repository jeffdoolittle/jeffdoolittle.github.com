package com.jdfx.numbers.services;

import com.jdfx.numbers.services.model.DeduplicatorResult;

public interface Deduplicator {
  DeduplicatorResult check(String value);
}