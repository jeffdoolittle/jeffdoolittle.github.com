package com.jdfx.numbers.services;

import com.jdfx.numbers.services.model.DecodedInput;
import com.jdfx.numbers.services.model.ValidationResult;

public interface Validator {
  ValidationResult validate(DecodedInput decodedInput);
}