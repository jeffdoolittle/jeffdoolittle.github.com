package com.jdfx.numbers.services;

import java.util.regex.Pattern;

import com.jdfx.numbers.services.model.DecodedInput;
import com.jdfx.numbers.services.model.ValidationResult;

public class ValidatorImpl implements Validator {
  private final AppConfiguration configuration;

  public ValidatorImpl(final AppConfiguration configuration) {
    super();
    this.configuration = configuration;
  }

  @Override
  public ValidationResult validate(DecodedInput decodedInput) {
    var newLine = configuration.newline();
    var input = decodedInput.toString();
    if (!input.endsWith(newLine)) {
      return new ValidationResultImpl(null, "Input was not valid. It must be terminated by a server-native new line.");
    }

    input = input.trim();

    if (input.equals(configuration.terminateMessage())) {
      return new ValidationResultImpl(input, null);
    }

    var regex = "^[0-9]{9}$";
    var pattern = Pattern.compile(regex);
    var matcher = pattern.matcher(input);
    var validatedValue = matcher.matches() ? input : null;
    var message = matcher.matches() ? null
        : String.format("Input was not valid. It must be a string of exactly 9 characters in length comprised of numbers only or the command '%s'.", configuration.terminateMessage());

    return new ValidationResultImpl(validatedValue, message);
  }

  class ValidationResultImpl implements ValidationResult {

    private String validatedValue;
    private String errorMessage;

    public ValidationResultImpl(String validatedValue, String errorMessage) {
      super();
      this.validatedValue = validatedValue;
      this.errorMessage = errorMessage == null ? "" : errorMessage;
    }

    @Override
    public String validatedValue() {
      return validatedValue;
    }

    @Override
    public boolean isValid() {
      return errorMessage.isEmpty();
    }

    @Override
    public String errorMessage() {
      return errorMessage;
    }
  }

}