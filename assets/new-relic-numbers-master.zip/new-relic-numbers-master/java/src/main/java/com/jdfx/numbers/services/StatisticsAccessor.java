package com.jdfx.numbers.services;

import com.jdfx.numbers.services.model.StatisticsContext;

public interface StatisticsAccessor {
  void increment(String key);

  void write(StatisticsContext context);

  static final String UNIQUE = "/stats/unique";
  static final String DUPLICATE = "/stats/duplicate";
}