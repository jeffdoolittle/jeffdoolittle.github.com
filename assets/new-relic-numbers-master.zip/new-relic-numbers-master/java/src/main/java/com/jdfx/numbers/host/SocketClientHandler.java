package com.jdfx.numbers.host;

import java.io.IOException;
import java.net.Socket;

import com.jdfx.numbers.services.Services;

public class SocketClientHandler extends Thread {

  private Services services;
  private Socket socket;

  public SocketClientHandler(Services services, Socket socket) {
    super();
    this.services = services;
    this.socket = socket;
  }

  @Override
  public void run() {
    try {

      services.log("DBG", "Opening input stream");

      var stream = socket.getInputStream();
      var processor = services.processor();
      processor.process(stream);
      stream.close();

      services.log("DBG", "Closing input stream");

    } catch (IOException e) {
      services.log(e);
    }

    services.log("DBG", "Thread complete");
  }
}