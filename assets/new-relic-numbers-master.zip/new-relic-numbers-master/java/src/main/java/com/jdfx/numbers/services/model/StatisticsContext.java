package com.jdfx.numbers.services.model;

import java.io.OutputStream;

public class StatisticsContext {
  private OutputStream stream;
  private boolean resetIntervalMeasurements;
  private boolean resetTotalMeasurements;

  public StatisticsContext(OutputStream stream, boolean resetIntervalMeasurements, boolean resetTotalMeasurements) {
    super();
    this.stream = stream;
    this.resetIntervalMeasurements = resetIntervalMeasurements;
    this.resetTotalMeasurements = resetTotalMeasurements;
  }

  public OutputStream stream() {
    return stream;
  }

  public boolean resetIntervalMeasurements() {
    return resetIntervalMeasurements;
  }

  public boolean resetTotalMeasurements() {
    return resetTotalMeasurements;
  }
}