package com.jdfx.numbers.services;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

// todo: allow setting app configuration from command line parameters
// or a configuration file.

public interface AppConfiguration {

  default int port() {
    return 4000;
  }

  default int backlog() {
    return 5;
  }

  default String newline() {
    return System.lineSeparator();
  }

  default String terminateMessage() {
    return "terminate";
  }

  default Charset charset() {
    return StandardCharsets.UTF_8;
  }

  default String eventsResourceName() {
    return "numbers.log";
  }

  default int statisticsIntervalMilliseconds() {
    return 10000;
  }
}