package com.jdfx.numbers.services;

import java.io.InputStream;

public interface NumberProcessor {
  void process(InputStream stream);
}