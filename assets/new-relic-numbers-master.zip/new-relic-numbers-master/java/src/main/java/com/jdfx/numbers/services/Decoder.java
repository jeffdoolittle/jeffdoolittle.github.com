package com.jdfx.numbers.services;

import java.nio.charset.Charset;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

import com.jdfx.numbers.services.model.DecodedInput;
import com.jdfx.numbers.util.NumbersException;

public interface Decoder {

  default DecodedInput Decode(final InputStream stream, final Charset c, final String newline) throws NumbersException {
    var maxLength = 9;
    var bufferSize = maxLength + newline.length();
    var buffer = new byte[bufferSize];

    try {
      var bytesRead = stream.read(buffer);
      if (stream.read() != -1) {
        throw new IOException(String.format("Input exceeds maximum allowed length of %s ", maxLength));
      }
      var bb = ByteBuffer.wrap(buffer);
      var decoded = c.decode(bb).toString();

      if(bytesRead <= 0 || decoded.trim().isEmpty()){
        throw new IOException("Input length canot be zero");
      }

      return new DecodedInput(decoded.replace("\0", ""));

      } catch (Exception e) {
        throw new NumbersException("A Decoding exception occurred.", e);
    }
  }
}