# Numbers

## About

See [`requirements.md`](requirements.md)

## TL;DR

Open two terminals.

`./server` in one and `./client {message}` in the other.

Have fun!

## Getting started

Validate the build is working in your environment:

`$ gradle build`

Run the tests:

`$ gradle test`

To build a jar for distribution

`$ gradle fatJar`

## Console

After building the jar with `$ gradle fatJar` you can run the application using the jar like this:

`java -jar ./build/libs/com.jdfx.numbers-all.jar console 123456789 123456788 123456789`

The output will look like this:

```text
Received 1 unique numbers, 0 duplicates. Unique total: 1
Received 1 unique numbers, 0 duplicates. Unique total: 2
Received 0 unique numbers, 1 duplicates. Unique total: 2
[WRN] - Shutting down...
```

To run the application as a socket listening host, execute this (the "socket" argument is optional):

# Socket Server

run `server` to startup the socket server.

# Client

You can execute the bash test client from the terminal.

`./client 123456789`

You can supply any input you like and see how the server responds.

## Testing

To continually run tests and refresh when changes are made, first install `live-server`

`$ npm install -g live-server`

Then you can run the test continually by executing:

`$ ./run_tests`
